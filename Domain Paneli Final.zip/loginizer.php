<?php
session_start();
include("Fonksiyonlar/Baglanti.php"); 

$username=$_POST['usn'];
$password=$_POST['pass'];

//kullanıcı adı ve şifeyi sorguluyoruz
$sql="SELECT * FROM admin WHERE user='$username' and pass='$password'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result,MYSQLI_ASSOC);

if(mysqli_num_rows($result) == 1)
{
$_SESSION['username'] = $username;
header("location: basarili.php"); 
}else
{
header("location: hatali.php"); 
}
?>