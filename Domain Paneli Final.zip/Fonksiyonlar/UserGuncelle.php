<?php 
include('Baglanti.php');
if ($_POST) { 
    
    $username = $_POST['username']; 
    $password = $_POST['password'];

    if ($username<>"" && $password<>"") { 
        
        // Veri güncelleme sorgumuzu yazıyoruz.
        if ($conn->query("UPDATE admin SET user = '$username', pass = '$password' WHERE id = 1")) 
        {
            header("location:../cikis.php"); 
            
        }
        else
        {
            echo "Hata oluştu"; 
        }
    }
}
?>