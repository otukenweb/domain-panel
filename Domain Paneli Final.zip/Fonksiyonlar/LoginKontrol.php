<?php
session_start();
include('Baglanti.php');
$user_check=$_SESSION['username'];
$sql = mysqli_query($conn,"SELECT * FROM uye WHERE kullaniciadi='$user_check' ");
$row=mysqli_fetch_array($sql,MYSQLI_ASSOC);
$login_user=$row['username'];
if(!isset($user_check))
{
header("Location: login.php");
}
?>