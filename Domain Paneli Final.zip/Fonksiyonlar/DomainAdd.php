<?php 
include('Baglanti.php');
if ($_POST) { 
    
    //$id = $_POST['id']; 
    $domain = $_POST['domain']; 
    $ktarih = $_POST['k_tarihi']; 
    $btarih = $_POST['b_tarihi'];
    $starih = $_POST['sk_tarihi'];
    $durum = $_POST['durum'];
    $sql="INSERT INTO `domainler` (`domain`, `k_tarih`, `b_tarih`, `s_tarih`, `durum`) VALUES ('$domain', '$ktarih', '$btarih', '$starih', '$durum');";
    $res=mysqli_query($conn,$sql);
    if ($res)
        header("location:../basarili.php"); 
    else
         header("location:../hatali.php"); 



}


?>