<?php
error_reporting(0);
$conn = mysqli_connect("localhost","root","","domainpaneli"); //VERİ TABANI BİLGİLERİ BURAYA EKLENECEK


if (mysqli_connect_errno()){
    
    echo "Bağlantısı Başarısız. Hata: " . mysqli_connect_error();
}else
{
    
}

?>